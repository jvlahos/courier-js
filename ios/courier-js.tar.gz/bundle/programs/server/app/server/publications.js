(function(){Meteor.publish('posts', function(options) {
	check(options, {
    	sort: Object,
    	limit: Number
  	});
	return Posts.find({}, options);
});

Meteor.publish('singlePost', function(id) {
	check(id, String)
	return Posts.find(id);
});

Meteor.publish('userPosts', function(id) {
	check(id, String)
	return Posts.find({userId : id});
});

})();
