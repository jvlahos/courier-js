(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Embedly, embedly;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/mswartz:embedly/embedly.js                                                                    //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
//This returns a JSON object with all sorts of goodies about the URL                                      // 1
//EXTRACT Docs: http://embed.ly/docs/api/extract/endpoints/1/extract                                      // 2
//EMBED Docs: http://embed.ly/docs/api/embed/endpoints/1/oembed                                           // 3
                                                                                                          // 4
//Currently only supports Extract and Embed, no more params yet.                                          // 5
//Thanks to Jeff Vlahos (@jvlahos), Andrew Pellett (@anrope) for a helpful blog post and Embedly          // 6
                                                                                                          // 7
Embedly = {                                                                                               // 8
	extract: function(url) {                                                                                 // 9
		var eSuccess = false;                                                                                   // 10
                                                                                                          // 11
		if(Meteor.settings.public.embedlyApiKey){                                                               // 12
			var embedlyKey = Meteor.settings.public.embedlyApiKey;                                                 // 13
		} else {                                                                                                // 14
			var embedlyKey = Meteor.settings.embedlyApiKey;                                                        // 15
		}                                                                                                       // 16
                                                                                                          // 17
		var embedlyURL = "http://api.embed.ly/1/extract?key=" + embedlyKey + "&url=" + encodeURIComponent(url); // 18
		$.ajax({                                                                                                // 19
			type: 'GET',                                                                                           // 20
			url: embedlyURL,                                                                                       // 21
			dataType: 'json',                                                                                      // 22
			data: {},                                                                                              // 23
			async: false,                                                                                          // 24
			error: function(xhr) {                                                                                 // 25
				console.log('Embed.ly failed to return useful data about this particular URL.', xhr);                 // 26
				eSuccess = false;                                                                                     // 27
			},                                                                                                     // 28
			success: function(data) {                                                                              // 29
				embedly = data;                                                                                       // 30
				eSuccess = true;                                                                                      // 31
			}                                                                                                      // 32
		});                                                                                                     // 33
		if (eSuccess) {                                                                                         // 34
			return embedly;                                                                                        // 35
		} else {                                                                                                // 36
			return false;                                                                                          // 37
		}                                                                                                       // 38
	},                                                                                                       // 39
	embed: function(url) {                                                                                   // 40
		var eSuccess = false;                                                                                   // 41
                                                                                                          // 42
		if(Meteor.settings.public.embedlyApiKey){                                                               // 43
			var embedlyKey = Meteor.settings.public.embedlyApiKey;                                                 // 44
		} else {                                                                                                // 45
			var embedlyKey = Meteor.settings.embedlyApiKey;                                                        // 46
		}                                                                                                       // 47
                                                                                                          // 48
		var embedlyURL = "http://api.embed.ly/1/oembed?key=" + embedlyKey + "&url=" + encodeURIComponent(url);  // 49
		$.ajax({                                                                                                // 50
			type: 'GET',                                                                                           // 51
			url: embedlyURL,                                                                                       // 52
			dataType: 'json',                                                                                      // 53
			data: {},                                                                                              // 54
			async: false,                                                                                          // 55
			error: function(xhr) {                                                                                 // 56
				console.log('Embed.ly failed to return useful data about this particular URL.', xhr);                 // 57
				eSuccess = false;                                                                                     // 58
			},                                                                                                     // 59
			success: function(data) {                                                                              // 60
				embedly = data;                                                                                       // 61
				eSuccess = true;                                                                                      // 62
			}                                                                                                      // 63
		});                                                                                                     // 64
		if (eSuccess) {                                                                                         // 65
			return embedly;                                                                                        // 66
		} else {                                                                                                // 67
			return false;                                                                                          // 68
		}                                                                                                       // 69
	}                                                                                                        // 70
}                                                                                                         // 71
                                                                                                          // 72
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mswartz:embedly'] = {
  Embedly: Embedly
};

})();

//# sourceMappingURL=mswartz_embedly.js.map
